// DM2008 — Mini Project
// PONG (Starter Scaffold)

/* ----------------- Globals ----------------- */
let leftPaddle, rightPaddle, ball;
let leftScore = 0;
let rightScore = 0;
let timerDuration = 3000;
let angryDuration = 1000;

let startTime, angryTime;
let ballState = "happy";
let gameState = "waiting";

/* ----------------- Setup & Draw ----------------- */
async function setup() {
  createCanvas(640, 360);
  noStroke();
  leftPaddle = new Paddle(30, height / 2 - 30, 20, 60);
  rightPaddle = new Paddle(width - 40, height / 2 - 30, 20, 60);
  ball = new Ball(width / 2, height / 2, 8);

  startTime = millis();

  imgBallHappy = await loadImage("ball_happy.png");
  imgBallAngry = await loadImage("ball_angry.png");
  imgPaddleRight = await loadImage("paddle_right.png");
  imgPaddleLeft = await loadImage("paddle_left.png");
  imgbg = await loadImage("background.png");
  fontSoA = await loadFont("Spell of Asia.ttf");
}

function draw() {
  imageMode(CORNER);
  image(imgbg, 0, 0, 640, 360);

  textFont(fontSoA);

  if (gameState == "waiting") {
    handleInput();

    leftPaddle.update();
    rightPaddle.update();

    ball.checkWallBounce();
    ball.checkPaddleBounce(leftPaddle);
    ball.checkPaddleBounce(rightPaddle);

    drawCourt();
    leftPaddle.show();
    rightPaddle.show();
    ball.show();

    startGame();
  }

  if (gameState == "playing") {
    handleInput();

    leftPaddle.update();
    rightPaddle.update();
    ball.update();

    ball.checkWallBounce();
    ball.checkPaddleBounce(leftPaddle);
    ball.checkPaddleBounce(rightPaddle);

    drawCourt();
    leftPaddle.show();
    rightPaddle.show();
    ball.show();

    if (ballState == "angry") {
      let elapsed = millis() - angryTime;
      if (elapsed >= angryDuration) {
        ballState = "happy";
      }
    }

    score();
    if (ball.pos.x < 0) {
      rightScore++;
      ball.reset();
    }
    if (ball.pos.x > width) {
      leftScore++;
      ball.reset();
    }
  }
  if (rightScore == 3 || leftScore == 3) {
    gameState = "gameover";
  }

  if (gameState == "gameover") {
    fill(255);
    textSize(48);
    textAlign(CENTER);
    text("Winner", width / 2, 70);
    textSize(38);
    if (rightScore == 3) {
      text("Player 2", width / 2, 120);
    }
    if (leftScore == 3) {
      text("Player 1", width / 2, 120);
    }
    text(leftScore, 280, height / 2);
    text(rightScore, 360, height / 2);

    fill(255);
    textSize(12);
    textAlign(CENTER);
    text("Press Space to continue", width / 2, 300);
  }
}

function startGame() {
  let elapsed = millis() - startTime;

  let secondsLeft = round((timerDuration - elapsed) / 1000);
  fill(255);
  textSize(70);
  textAlign(CENTER);
  text(secondsLeft, width / 2, 120);
  textSize(38);

  if (elapsed >= timerDuration) {
    gameState = "playing";
  }
}

function keyPressed() {
  if (gameState == "gameover" && keyCode == 32) {
    startTime = millis();
    gameState = "waiting";
    rightScore = 0;
    leftScore = 0;
  }
}

/* ----------------- Input ----------------- */
function handleInput() {
  if (keyIsDown("w")) {
    leftPaddle.vy = -leftPaddle.speed;
  }
  if (keyIsDown("s")) {
    leftPaddle.vy = leftPaddle.speed;
  }
  if (keyIsDown(UP_ARROW)) {
    rightPaddle.vy = -rightPaddle.speed;
  }
  if (keyIsDown(DOWN_ARROW)) {
    rightPaddle.vy = rightPaddle.speed;
  }
}

function keyReleased() {
  leftPaddle.vy = 0;
  rightPaddle.vy = 0;
}

/* ----------------- Classes ----------------- */
class Paddle {
  constructor(x, y, w, h) {
    this.pos = createVector(x, y);
    this.w = w;
    this.h = h;
    this.vy = 0;
    this.speed = 5;
  }

  update() {
    this.pos.y += this.vy;
    this.pos.y = constrain(this.pos.y, 0, height - this.h);
  }

  show() {
    image(imgPaddleLeft, this.pos.x, this.pos.y, this.w, this.h);
  }
}

class Ball {
  constructor(x, y, r) {
    this.pos = createVector(x, y);
    this.r = r;
    this.xSpeed = 3;
    this.ySpeed = 3;

    this.vel = createVector(
      random([-1, 1]) * this.xSpeed,
      random([-1, 1]) * this.ySpeed
    );
  }

  update() {
    this.pos.add(this.vel);
  }

  checkWallBounce() {
    if (this.pos.y - this.r <= 0 || this.pos.y + this.r >= height) {
      this.vel.y *= -1;
      this.pos.y = constrain(this.pos.y, this.r, height - this.r);
    }
  }

  checkPaddleBounce(paddle) {
    const withinY =
      this.pos.y > paddle.pos.y && this.pos.y < paddle.pos.y + paddle.h;
    const withinX =
      this.pos.x + this.r > paddle.pos.x &&
      this.pos.x - this.r < paddle.pos.x + paddle.w;

    if (withinX && withinY) {
      if (this.vel.x < 0) {
        this.pos.x = paddle.pos.x + paddle.w + this.r;
      } else {
        this.pos.x = paddle.pos.x - this.r;
      }
      this.vel.x *= -1;
      this.vel.y += (this.pos.y - paddle.pos.y - paddle.h / 2) * 0.1;

      this.vel.x *= 1.1;
      this.vel.y *= 1.1;

      ballState = "angry";
      angryTime = millis();
    }
  }

  show() {
    if (ballState == "angry") {
      push();
      imageMode(CENTER);
      image(imgBallAngry, this.pos.x, this.pos.y, 32, 32);
      pop();
    } else {
      push();
      imageMode(CENTER);
      image(imgBallHappy, this.pos.x, this.pos.y, 32, 32);
      pop();
    }
  }

  reset() {
    this.pos.set(width / 2, height / 2);
    ballState = "happy";
    this.vel = createVector(
      random([-1, 1]) * this.xSpeed,
      random([-1, 1]) * this.ySpeed
    );
  }
}

/* ----------------- UI Helpers ----------------- */
function drawCourt() {
  stroke(80);
  strokeWeight(2);
  for (let y = 10; y < height; y += 18) {
    line(width / 2, y, width / 2, y + 8);
  }
  noStroke();
}

function score() {
  fill(255);
  textSize(48);
  textAlign(CENTER);
  text(leftScore, 280, height / 5);
  text(rightScore, 360, height / 5);
}
