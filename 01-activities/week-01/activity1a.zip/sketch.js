// DM2008 — Activity 1a
// Simple Creatures (20 min)

// Run the sketch, then click on the preview to enable keyboard
// Use the 'Option' ('Alt' on Windows) key to view or hide the grid
// Use the 'Shift' key to change overlays between black & white
// Write the code for your creature within the space provided

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(240);

  noStroke();
  fill("#947248");
  // ears
  ellipse (175, 115, 30, 100);
  ellipse (225, 115, 30, 100);
  // body
  triangle (200, 150, 150, 285, 250, 285);
  // head
  ellipse (200, 170, 100, 100);
  fill("#000000");
  // eyes
  ellipse (176, 180, 10, 10);
  ellipse (224, 180, 10, 10);

  
  helperGrid(); // do not edit or remove this line
}
