// DM2008 — Activity 1b [Georg Nees]
// Learning By Making (30 min)

let x;
let y;
let w;

function setup() {
  createCanvas(800, 800)
  background(240);
}

function draw() {
  
  x = random(0,800);
  y = random(300,400);
  w = random(10, 100);
  
  // background(45, 166, 148, 5);
  background(26, 25, 23, 10);
  
  // stroke(50);
  // strokeWeight(random(0.5, 2));
  // strokeWeight(1);
  noStroke();
  // noFill();
  fill(50, 230, random(255));
  rect(x, y, w, w+(random(10, 100)));
  fill(250, random(194, 228), 62);
  rect(random(0,800), random(0,800), w-50, w-50);

}
 
function keyPressed() {
    saveCanvas("activity1b-image", "jpg");
}