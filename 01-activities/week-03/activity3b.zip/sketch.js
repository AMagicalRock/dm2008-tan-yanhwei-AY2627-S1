// DM2008 — Activity 3b
// One Function Wonder (30 min)
//
// Write a function that draws a shape or group of shapes.
// It should take at least one parameter — try x, y, size, or color.
// Call it several times with different values to create variation.
//
// Ideas: a simple face, a flower, a house, an icon.
// Example: myShape(100, 200, 50); myShape(300, 200, 80);
//
// Stretch: call your function inside a for loop to create a repeating pattern.

function setup() {
  createCanvas(400, 400);
  rectMode(CENTER);
}

function draw() {
  background(color("#080e3a"));
  noStroke();

  shape (width - 70, height - 330, 100, 100, color("#dfeff1"));
  
  stair(-255, 30, 300, 50, color("#2e36a3"));
  stair(-80, 30, 25, 50, color("#58ccfe"));
  stair(-30, 30, 50, 50, color("#c6f226"));
  stair(60, 30, 100, 50, color("#fecc16"));
}

// Define your function outside draw()
// It can be called from anywhere in your sketch

function stair(x, y, w, h, c) {
  for (let i = 0; i <= height; i += 60) {
    fill(c);
    rect(x + i, y + i, w, h);
  }
}

function shape(x, y, w, h, c) {
  fill(c);
  rect(x, y, w, h);
}