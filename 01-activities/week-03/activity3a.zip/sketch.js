// DM2008 — Activity 3a [Guided]
// Array Sampler (25 min)
//
// An array stores a list of values — here it's colors, but it could be
// sizes, positions, or anything else.
// Press any key to cycle through the array one item at a time.
//
// Try these:
// - Replace the colors with your own values (sizes, positions, text).
// - Use mousePressed() instead of keyPressed().
// - Use push() to add new items or splice() to remove them.
// - Loop through the whole array to draw all items at once.
//
// Stretch: visualize all items in the array simultaneously instead of one at a time.

let palette = ["#ffbff2", "#f29bd1", "#e675ad", "#de4985"];
let currentIndex = 0;

function setup() {
  createCanvas(400, 400);
  noStroke();
  frameRate(1);
}

function draw() {
  background(255, 235, 243);

  // Draw the ellipse using the current color in the array
    fill(palette[currentIndex]);
    ellipse(width / 2, height / 2, 200);

  currentIndex ++

    if (currentIndex >= palette.length) {
    currentIndex = 0;
}

// Advance to the next color each time a key is pressed
function mousePressed() {
  currentIndex++; // shorthand for currentIndex += 1
  console.log("Current index:", currentIndex, "→", palette[currentIndex]);
  if (currentIndex >= palette.length) {
    currentIndex = 0;
  }
}

function keyPressed() {
  if (key == 1) {
    palette.push("#a1e7ed");
  }
  if (key == 2) {
    palette.splice(4, 1);
  }
}
