// DM2008 — Activity 2a [Guided]
// Mode Switch (20 min)
//
// Keys 1, 2, 3 switch between modes — each one changes the background color.
// Try extending each mode to also change the fill, size, or speed of the ellipse.
// Keep it simple: one clear change per mode that's easy to see on screen.
//
// Stretch: add a 4th mode, or make the ellipse change shape between modes.

let x = 0;       // ellipse x-position
let size = 50;   // ellipse size
let bgColor;     // background color, changed by key presses
let mode = 0;

function setup() {
  createCanvas(400, 400);
  bgColor = color(220);
}

function draw() {
  background(bgColor);

  // --- Your if/else goes here ---
  // Try swapping this out for your own rule.
  noStroke();
  if (mouseIsPressed) {
    if(mode == 1) {
      fill(247, 193, 242);
    } else if (mode == 2) {
      fill(185, 237, 230);
    } else if (mode == 3) {
      fill(250, 248, 205);
    } else {
      fill(200);
    }
  } else {
    fill(255, 255, 255);
  }

  // Draw the ellipse at its current position
  ellipse(x, height / 2, size);

  // Move the ellipse
  x += 2;

  // Wrap around when it exits the right edge
  if (x > width + size / 2) {
    x = 0;
  }
}

// Keys 1, 2, 3 change the background color — this is your mode switch
function keyPressed() {
  switch (key) {
    case "1":
      bgColor = color(235, 52, 158);
      size = size * 1.5;
      mode = 1;
      break;
    case "2":
      bgColor = color(36, 179, 150);
      size = size + 10;
      mode = 2;
      break;
    case "3":
      bgColor = color(217, 185, 24);
      size = size - 25;
      mode = 3;
      break;
    case "4":
      bgColor = color(220); // grey
      mode = 0;
  }
}
