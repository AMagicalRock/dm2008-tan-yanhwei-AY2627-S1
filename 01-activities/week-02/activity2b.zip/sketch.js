// DM2008 — Activity 2b [Guided]
// Pattern Making (40 min)
//
// Use a for loop to draw a repeating row of shapes.
// Add a condition to introduce variation — alternating color, size, or spacing.
// Then add one interaction (mouse or key) that changes the rule.
//
// Stretch: try a second row, or turn your row into a 2D grid.

x = -100;
y = -100;
z = -100;

function setup() {
  createCanvas(400, 500);
}

function draw() {
  background(0,10);

  for (let u = 0; u < width; u += 50) {
    if (mouseIsPressed) {
      fill(87, random(255), 250);
      rect (u + 5, height / 4, 40);
    } else if (u % 100 == 0) {
      fill(100);
      ellipse (u + 25, height / 3.5, 40);
    } else {
      fill(180);
      rect (u + 5, height / 4, 40);
    }
  }
  
  for (let i = 0; i < width; i += 50) {
    // % (modulo) alternates between 0 and non-zero — good for switching every other shape
    if (mouseIsPressed) {
      fill(random(255), 204, 45);
      rect (i + 5, height / 1.75, 40);
    } else if (i % 100 == 0) {
      fill(100);
      rect (i + 5, height / 1.75, 40);
    } else {
      fill(180);
      ellipse (i + 25, height / 1.63, 40);
    }
  }

  for (let v = 0; v < width; v += 50) {
    if (mouseIsPressed) {
      fill(242, 78, random(255));
      rect (v + 5, height / 1.15, 40);
    } else if (v % 100 == 0) {
      fill(100);
      ellipse (v + 25, height / 1.1, 40);
    } else {
      fill(180);
      rect (v + 5, height / 1.15, 40);
    }
  }

  if (mouseIsPressed) {
    fill(62, 187, 237);
  }
  rect (x = x + 5, height / 16, 60, 80);
  if (x > 450) {
    x = -100;
  }
  if (mouseIsPressed) {
    fill(89, 201, 48);
  }
  rect (y = y + 3, height / 2.35, 100, 60);
  if (y > 450) {
    y = -100;
  }
  if (mouseIsPressed) {
    fill(227, 59, 140);
  }
  rect (z = z + 7, height / 1.38, 80, 65);
  if (z > 450) {
    z = -100;
  }
  
}